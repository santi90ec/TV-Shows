from django.apps import AppConfig


class AppcrudConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appCrud'
